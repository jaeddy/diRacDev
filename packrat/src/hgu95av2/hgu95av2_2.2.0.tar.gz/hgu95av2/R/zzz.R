.onLoad <- function(libname, pkgname)
    packageStartupMessage(sprintf(
"\n******* Deprecation warning *******:\n\nThe package '%s' is deprecated and will not be supported in the future. \n\nInstead we strongly reccomend that you should start using the '%s.db' package. \n\nWe hope you will enjoy these new packages.  If you still have questions, you can search \n(http://dir.gmane.org/gmane.science.biology.informatics.conductor) or ask the mailing list \n(http://bioconductor.org/docs/mailList.html).  \n\n", pkgname, pkgname)) 
