hgu95av2 <- function() cat(hgu95av2QC)
.no_S3_generics = TRUE
ns <- asNamespace("hgu95av2")
