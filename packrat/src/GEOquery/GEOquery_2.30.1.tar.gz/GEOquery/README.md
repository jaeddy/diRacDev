## Installation

To install from Bioconductor, use the following code:

```{r}
source("http://bioconductor.org/biocLite.R")
biocLite("GEOquery")
```

To install directly from github:

```{r}
library(devtools)
install_github('GEOquery','seandavi')
```
